package com.example.usan1;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.CustomViewHolder> {
    private List<Product> productList;
    private Context context;


    public CustomAdapter(List<Product> productList, FragmentActivity mainActivity) {
        this.productList = productList;
        this.context = context;
    }

    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_home, parent, false);
        CustomViewHolder holder = new CustomViewHolder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder holder, int position) {
        Glide.with(holder.itemView)
                .load(productList.get(position).getPd_img())
                .into(holder.iv_pd_img);
        holder.tv_id.setText(productList.get(position).getId());
        holder.tv_price.setText(String.valueOf(productList.get(position).getPrice()));
        holder.tv_author.setText(productList.get(position).getAuthor());
    }

    @Override
    public int getItemCount() {
        return (productList != null ? productList.size() : 0); //삼항연산자
    }

    public class CustomViewHolder extends RecyclerView.ViewHolder {
        ImageView iv_pd_img;
        TextView tv_id;
        TextView tv_price;
        TextView tv_author;

        public CustomViewHolder(@NonNull View itemView) {
            super(itemView);
            this.iv_pd_img = itemView.findViewById(R.id.iv_pd_img);
            this.tv_id = itemView.findViewById(R.id.tv_id);
            this.tv_price = itemView.findViewById(R.id.tv_price);
            this.tv_author = itemView.findViewById(R.id.tv_author);
        }
    }
}
