package com.example.usan1;

import static android.content.ContentValues.TAG;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.http.GET;
import retrofit2.http.Query;

public class HomeFragment extends Fragment {

    private RecyclerView recyclerView;
//    private RecyclerView.Adapter customadapter;
    private CustomAdapter customAdapter;
    private RecyclerView.LayoutManager layoutManager;
    private ArrayList<Product> arrayList;
    FloatingActionButton fab;
    private Button myButton;
    public HomeFragment() {
        // Required empty public constructor
    }

    public static HomeFragment newInstance() {
        HomeFragment fragment = new HomeFragment();
        return fragment;
    }

    public interface ProductService {
        @GET("display/productList") // API 엔드포인트 설정
        Call<List<Product>> getProducts(@Query("page") int page, @Query("pager_per") int perPage); // 상품 목록을 가져오는 API 메서드 정의
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // 리사이클러뷰 객체 생성
        recyclerView = view.findViewById(R.id.recycler_view);

        // 레이아웃 매니저 설정
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);

        // 어댑터 생성 및 설정
        ArrayList<Product> productList = new ArrayList<>(); // 빈 상품 목록 생성
        customAdapter = new CustomAdapter(productList, getActivity()); // 어댑터 생성
        recyclerView.setAdapter(customAdapter); // 어댑터 설정

        OkHttpClient client = new OkHttpClient.Builder()
                .connectTimeout(99999, TimeUnit.SECONDS) // 연결 타임아웃 시간을 60초로 설정
                .readTimeout(99999, TimeUnit.SECONDS) // 읽기 타임아웃 시간을 60초로 설정
                .build();

        //Retrofit 객체 생성
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://13.209.12.47:55924/") // API 주소 설정
                .addConverterFactory(GsonConverterFactory.create()) // JSON 데이터를 자바 객체로 변환할 Gson 컨버터 추가
                .build();


        // Retrofit 객체를 사용하여 API 인터페이스 구현체 생성
        ProductService productService = retrofit.create(ProductService.class);

        // API 호출 및 응답 처리
        Call<List<Product>> call = productService.getProducts(1,2);
        call.enqueue(new Callback<List<Product>>() {
            @Override
            public void onResponse(Call<List<Product>> call, Response<List<Product>> response) {
                if (response.isSuccessful()) {
                    List<Product> productList = response.body();

                    // 상품 목록을 리사이클러뷰 어댑터에 설정
                    CustomAdapter customAdapter = new CustomAdapter(productList, getActivity());
                    recyclerView.setAdapter(customAdapter);
                } else {
                    // API 호출 실패 처리
                    Log.e(TAG, "API 호출 실패: " + response.message());
                }
            }

            @Override
            public void onFailure(Call<List<Product>> call, Throwable t) {
                // API 호출 실패 처리
                Log.e(TAG, "API 호출 실패", t);
            }
        });


        // 상품 상세 페이지로 이동하는 버튼
        Button myButton = view.findViewById(R.id.testbtn);
        myButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), productdetailactivity.class);
                startActivity(intent);
            }
        });

        // 업로드 페이지로 이동하는 버튼

        fab = view.findViewById(R.id.fab);

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), UploadActivity.class);
                startActivity(intent);
            }
        });

        return view;
    }


}