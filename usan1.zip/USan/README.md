# USan

## Version 
- JAVA
- Android Studio
- Python == 3.9.16
- Flask == 2.2.3 
